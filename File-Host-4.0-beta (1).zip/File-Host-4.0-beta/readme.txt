/*

File Host - Yandex, Mediafire & Google Drive Direct Downloader 

Created Date :- 19 June 2022 

*/



Hello there,

You can use it for easyly 

First you can edit process.php line no 10

Modify "Shakib Ahmed" to "Your Name"

and 

header.php line no 2 

Modify "File Host" to "Your Website Name"

Thanks for using my service 
